<script src="https://developers.google.com/maps/documentation/javascript/examples/markerclusterer/markerclusterer.js"></script>
<script src="https://maps.googleapis.com/maps/api/js?key=["your-google-map-api"&libraries=places"></script>
<script src="<?php echo e(asset('dashboards/dist/js/app.js')); ?>"></script>
<script >function lettersOnly(input) {
    var regex = /[^a-z  ]/gi;
    input.value = input.value.replace(regex, "");
		}
    </script>


<script>
  const textInput = document.getElementById('nisn');
  textInput.addEventListener('input', () => {
    if (textInput.value.length < 5 || textInput.value.length > 10) {
      textInput.setCustomValidity('Text input must be between 5 and 10 characters.');
    } else {
      textInput.setCustomValidity('');
    }
  });
</script>

<?php echo $__env->yieldPushContent('js'); ?>
  <?php /**PATH C:\laragon\www\e-konseling\resources\views/template/scricpt.blade.php ENDPATH**/ ?>